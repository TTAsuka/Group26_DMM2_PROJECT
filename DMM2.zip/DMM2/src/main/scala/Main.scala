import scala.io.StdIn._
import java.time.{LocalDateTime, YearMonth}
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.format.{DateTimeFormatter, DateTimeParseException}
import scala.util.{Try, Success, Failure}
import scala.io.StdIn
import scala.annotation.tailrec
import java.time.{LocalDate, LocalDateTime, YearMonth}
import java.time.format.DateTimeFormatter

object Main extends App {

  @tailrec
  def mainMenu(): Unit = {
    println("\n--- Welcome to Renewable Energy Plant System! ---")
    println("1. Fetch and store data related to energy generated from renewable sources")
    println("2. Monitor and Control Energy Sources")
    println("3. View Energy Generation and Storage Data")
    println("4. Analyze Energy Data")
    println("5. Detect and handle issues with renewable energy sources")
    println("6. Exit")

    println("Select an option: ")
    val choice = readLine()

    choice match {
      case "1" => fetchDataForEnergySources()
      case "2" => monitorAndControl()
      case "3" => viewEnergy()
      case "4" => analyzeData()
      case "5" => detectAndHandleIssues()
      case "6" =>
        println("Exiting system...")
        return
      case _ =>
        println("Invalid choice, please enter a number between 1 and 6.")
    }

    mainMenu()
  }

  mainMenu()

  def fetchDataForEnergySources(): Unit = {
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
    println("Please enter the start time and end time of the data you want to obtain!")

    // Recursively read and validate start time
    val startTime = readDateTime("Enter the Start time (format yyyy-MM-dd HH:mm):", formatter)

    // Recursively read and validate end time
    val endTime = readDateTime("Enter the End time (format yyyy-MM-dd HH:mm):", formatter)

    val isoFormatter = DateTimeFormatter.ISO_DATE_TIME
    val formattedStartTime = startTime.format(isoFormatter) + "Z"
    val formattedEndTime = endTime.format(isoFormatter) + "Z"

    val api = new FetchAndSaveAPIData("https://data.fingrid.fi/api/data", "60ba3ea704b241f18e4ee3813423cdd4")
    val datasets = Map(248 -> "solar_data.json", 191 -> "hydro_data.json", 75 -> "wind_data.json")

    datasets.foreach { case (id, filename) =>
      println(s"Fetching data for dataset ID $id...")
      api.fetchData(id, formattedStartTime, formattedEndTime, filename)
    }
  }

  @tailrec
  def readDateTime(prompt: String, formatter: DateTimeFormatter): LocalDateTime = {
    println(prompt)
    Try(LocalDateTime.parse(readLine(), formatter)) match {
      case Failure(e: DateTimeParseException) =>
        println(s"Invalid date format, please use the correct format: yyyy-MM-dd HH:mm")
        readDateTime(prompt, formatter) // Recursive call
      case Failure(e) =>
        println(s"Unexpected error: ${e.getMessage}")
        readDateTime(prompt, formatter) // Recursive call on unexpected errors
      case scala.util.Success(dateTime) =>
        dateTime // Successfully parsed date
    }
  }

  def monitorAndControl(): Unit = {
    println("Monitoring and controlling energy sources...")

    val solarController = new EnergyController("E:\\project_scala\\DMM2\\solar_data.json")
    val windController = new EnergyController("E:\\project_scala\\DMM2\\wind_data.json")
    val hydroController = new EnergyController("E:\\project_scala\\DMM2\\hydro_data.json")

    println("Select the energy source to monitor and control:")
    println("1: Solar")
    println("2: Wind")
    println("3: Hydro")
    val choice = scala.io.StdIn.readInt()

    choice match {
      case 1 =>
        println("Monitoring and controlling Solar Energy:")
        solarController.displayAndOptionallyAdjustOutput()
      case 2 =>
        println("Monitoring and controlling Wind Energy:")
        windController.displayAndOptionallyAdjustOutput()
      case 3 =>
        println("Monitoring and controlling Hydro Energy:")
        hydroController.displayAndOptionallyAdjustOutput()
      case _ =>
        println("Invalid choice, please select a valid number (1, 2, or 3).")
    }
  }

  def viewEnergy(): Unit = {
    val viewer = new EnergyDataViewer(
      "E:\\project_scala\\DMM2\\solar_data.json",
      "E:\\project_scala\\DMM2\\hydro_data.json",
      "E:\\project_scala\\DMM2\\wind_data.json"
    )
    viewer.viewEnergyData()
  }

  def analyzeData(): Unit = {
    val energyTypes = Map(1 -> "solar", 2 -> "hydro", 3 -> "wind")
    val granularities = Map(1 -> "hourly", 2 -> "daily", 3 -> "weekly", 4 -> "monthly")

    println("Select the type of energy to analyze:")
    energyTypes.foreach { case (key, value) => println(s"$key: $value") }
    val energyTypeOption = energyTypes.get(readInt())

    if (energyTypeOption.isEmpty) {
      println("Invalid energy type selection.")
      return
    }
    val energyType = energyTypeOption.get

    println("Select the granularity of the data:")
    granularities.foreach { case (key, value) => println(s"$key: $value") }
    val granularityOption = granularities.get(readInt())

    if (granularityOption.isEmpty) {
      println("Invalid granularity selection.")
      return
    }
    val granularity = granularityOption.get

    val dateFormat = granularity match {
      case "monthly" => "yyyy-MM"
      case "daily"   => "yyyy-MM-dd"
      case "hourly"  => "yyyy-MM-dd HH:mm"
      case "weekly"  => "yyyy-MM-dd"
    }
    val dateFormatter = DateTimeFormatter.ofPattern(dateFormat)
    val isDateTime = granularity == "hourly"

    println(s"Enter the starting date for $granularity analysis ($dateFormat):")
    var startDateTimeStr = readLine()
    var startDateTimeOpt = validateDateTime(startDateTimeStr, dateFormatter, isDateTime)

    while (startDateTimeOpt.isEmpty) {
      println(s"Invalid date format. Please enter a date in the correct format ($dateFormat):")
      startDateTimeStr = readLine()
      startDateTimeOpt = validateDateTime(startDateTimeStr, dateFormatter, isDateTime)
    }

    val startDateTime = startDateTimeOpt.get
    var endDateTime: LocalDateTime = startDateTime

    granularity match {
      case "monthly" =>
        val startYM = YearMonth.parse(startDateTimeStr, dateFormatter)
        endDateTime = startYM.atEndOfMonth().atTime(23, 59)
      case "daily" =>
        endDateTime = startDateTime.plusDays(1).minusSeconds(1)
      case "hourly" =>
        println("Enter the ending date and time for hourly analysis (yyyy-MM-dd HH:mm):")
        var endDateTimeStr = readLine()
        var endDateTimeOpt = validateDateTime(endDateTimeStr, dateFormatter, true)
        while (endDateTimeOpt.isEmpty) {
          println(s"Invalid date format. Please enter a date in the correct format (yyyy-MM-dd HH:mm):")
          endDateTimeStr = readLine()
          endDateTimeOpt = validateDateTime(endDateTimeStr, dateFormatter, true)
        }
        endDateTime = endDateTimeOpt.get
      case "weekly" =>
        endDateTime = startDateTime.plusWeeks(1).minusSeconds(1)
    }

    val fileMap = Map(
      "solar" -> "E:\\project_scala\\DMM2\\solar_data.json",
      "hydro" -> "E:\\project_scala\\DMM2\\hydro_data.json",
      "wind" -> "E:\\project_scala\\DMM2\\wind_data.json"
    )

    fileMap.get(energyType) match {
      case Some(fileName) =>
        val dataAnalyzer = new DataAnalyzer()
        dataAnalyzer.analyze(fileName, granularity, startDateTime, endDateTime)
      case None =>
        println("Invalid energy type selected.")
    }
  }

  def validateDateTime(input: String, formatter: DateTimeFormatter, isDateTime: Boolean): Option[LocalDateTime] = {
    try {
      if (isDateTime) {
        Some(LocalDateTime.parse(input, formatter))
      } else {
        Some(LocalDate.parse(input, formatter).atStartOfDay())
      }
    } catch {
      case e: DateTimeParseException =>
        None
    }
  }

  implicit val defaultFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")

  def readDateTime(implicit formatter: DateTimeFormatter): LocalDateTime = {
    @tailrec
    def attemptRead(): LocalDateTime = {
      println("Enter date and time:")
      Try(LocalDateTime.parse(readLine(), formatter)) match {
        case Success(dateTime) => dateTime
        case Failure(_) =>
          println(s"Invalid date format, please use the correct format: yyyy-MM-dd HH:mm")
          attemptRead()
      }
    }
    attemptRead()
  }

  def detectAndHandleIssues(): Unit = {
    println("Detecting and handling issues...")

    val energyTypes = Map(
      1 -> ("solar", "E:\\project_scala\\DMM2\\solar_data.json"),
      2 -> ("hydro", "E:\\project_scala\\DMM2\\hydro_data.json"),
      3 -> ("wind", "E:\\project_scala\\DMM2\\wind_data.json")
    )

    println("Select the type of energy to detect issues (1: solar, 2: hydro, 3: wind):")
    energyTypes.foreach { case (key, (typeLabel, _)) => println(s"$key: $typeLabel") }

    val energyTypeKey = readLine()
    val selectedEnergy = Try(energyTypeKey.toInt).toOption.flatMap(energyTypes.get)

    selectedEnergy match {
      case Some((energyType, filePath)) =>
        val issueDetector = new IssueDetector(energyType, filePath)
        issueDetector.detectAndHandleIssues()
      case None =>
        println("Invalid input. Please enter a valid number corresponding to the energy type.")
    }
  }


}
